# Thư tỏ tình 4.0 💌
---
Tác giả chính: [Heryoka Kurniawan](https://github.com/heryyy)

Tham khảo: [Src Code gốc](https://github.com/heryyy/pink-envelope)

> Video Demo: [Xem tại đây](https://www.tiktok.com/@dr.gifter306/video/7527984331982114055)

> Video hướng dẫn: [Xem tại đây](https://drive.google.com/file/d/1xXZ-IXxMqBVU8TrOuHTWQJ_35uZhr2XI/view?usp=sharing)

---

![Làm Gif (3)](https://github.com/user-attachments/assets/053a0a32-6dce-43a6-a613-04ed846c0b7d)
